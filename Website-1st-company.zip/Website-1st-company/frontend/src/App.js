import React, { useState, useEffect } from 'react';
import './App.css';

const App = () => {
  const [moonPhase, setMoonPhase] = useState(0);
  const [showLogin, setShowLogin] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    country: '+1',
    email: '',
    language: 'es'
  });
  const [loginData, setLoginData] = useState({
    username: '',
    password: ''
  });

  // Moon phases animation
  useEffect(() => {
    const interval = setInterval(() => {
      setMoonPhase(prev => (prev + 1) % 8);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Binary code rain effect
  useEffect(() => {
    const canvas = document.getElementById('binary-canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const binary = "01";
    const fontSize = 16;
    const columns = canvas.width / fontSize;
    const drops = [];

    for (let x = 0; x < columns; x++) {
      drops[x] = 1;
    }

    function draw() {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#00ff41';
      ctx.font = fontSize + 'px monospace';

      for (let i = 0; i < drops.length; i++) {
        const text = binary.charAt(Math.floor(Math.random() * binary.length));
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
    }

    const interval = setInterval(draw, 50);
    return () => clearInterval(interval);
  }, []);

  const handleInputChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleLoginChange = (e) => {
    setLoginData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleLogin = (e) => {
    e.preventDefault();
    console.log('Login attempt:', loginData);
    alert('¡Acceso autorizado!');
    setShowLogin(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('¡Gracias por contactarnos! Te responderemos pronto.');
  };

  const countries = [
    { code: '+1', name: 'Estados Unidos/Canadá' },
    { code: '+52', name: 'México' },
    { code: '+502', name: 'Guatemala' },
    { code: '+503', name: 'El Salvador' },
    { code: '+504', name: 'Honduras' },
    { code: '+505', name: 'Nicaragua' },
    { code: '+506', name: 'Costa Rica' },
    { code: '+507', name: 'Panamá' },
    { code: '+34', name: 'España' },
    { code: '+57', name: 'Colombia' }
  ];

  const moonPhases = ['🌑', '🌒', '🌓', '🌔', '🌕', '🌖', '🌗', '🌘'];

  return (
    <div className="min-h-screen bg-gray-900 text-white relative overflow-hidden">
      {/* Binary Background Canvas */}
      <canvas id="binary-canvas" className="fixed inset-0 z-0" />
      
      {/* Background Building Image */}
      <div 
        className="fixed inset-0 z-10 opacity-50"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1705699650381-11613e5e2c14')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      />

      {/* Green Windows Overlay */}
      <div className="fixed inset-0 z-20 bg-gradient-to-b from-transparent via-green-900/5 to-transparent" />

      {/* Main Content */}
      <div className="relative z-30">
        {/* Header */}
        <header className="bg-black/20 backdrop-blur-md border-b border-green-500/20 relative">
          <div className="container mx-auto px-6 py-4">
            <div className="flex justify-between items-center">
              {/* Moon Phase Animation */}
              <div className="text-4xl animate-pulse">
                {moonPhases[moonPhase]}
              </div>
              
              {/* Navigation - moved closer to moon (1cm/38px from moon) */}
              <nav className="hidden md:flex space-x-8 absolute left-24">
                <a href="#home" className="text-green-400 hover:text-green-300 transition-colors font-semibold">Inicio</a>
                <a href="#services" className="text-white hover:text-green-300 transition-colors font-semibold">Servicios</a>
                <a href="#about" className="text-white hover:text-green-300 transition-colors font-semibold">Nosotros</a>
                <a href="#case-studies" className="text-white hover:text-green-300 transition-colors font-semibold">Casos de Estudio</a>
              </nav>

              {/* Animated Black Cat */}
              <div className="relative">
                <div 
                  className="w-16 h-16 bg-black rounded-full flex items-center justify-center relative overflow-hidden shadow-xl border-2 border-green-500/50 hover:border-green-400 transition-all duration-300 cursor-pointer"
                  onClick={() => setShowLogin(!showLogin)}
                >
                  <img 
                    src="https://images.unsplash.com/photo-1503431128871-cd250803fa41"
                    alt="Gato misterioso"
                    className="w-12 h-12 object-cover rounded-full hover:scale-110 transition-transform duration-300"
                    style={{
                      animation: 'catFadeInOut 4s ease-in-out infinite'
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-transparent rounded-full pointer-events-none"></div>
                </div>
                
                {/* Login Modal */}
                {showLogin && (
                  <div className="absolute top-20 right-0 w-80 bg-gray-900/95 backdrop-blur-md border-2 border-green-500/50 rounded-2xl shadow-2xl p-6 z-50 animate-fadeInUp">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-xl font-bold text-green-400">Acceso Administrativo</h3>
                      <button 
                        onClick={() => setShowLogin(false)}
                        className="text-gray-400 hover:text-white transition-colors"
                      >
                        ✕
                      </button>
                    </div>
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2 text-green-400">Usuario</label>
                        <input
                          type="text"
                          name="username"
                          value={loginData.username}
                          onChange={handleLoginChange}
                          className="w-full px-4 py-3 bg-gray-800/50 border border-green-500/30 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-white placeholder-gray-400"
                          placeholder="Ingrese su usuario"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2 text-green-400">Contraseña</label>
                        <input
                          type="password"
                          name="password"
                          value={loginData.password}
                          onChange={handleLoginChange}
                          className="w-full px-4 py-3 bg-gray-800/50 border border-green-500/30 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-white placeholder-gray-400"
                          placeholder="Ingrese su contraseña"
                          required
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full bg-green-600 hover:bg-green-700 px-4 py-3 rounded-lg font-semibold transition-all transform hover:scale-105 shadow-lg shadow-green-500/25"
                      >
                        Iniciar Sesión
                      </button>
                    </form>
                    <div className="mt-4 text-center">
                      <p className="text-xs text-gray-400">Solo para administradores autorizados</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <section id="home" className="container mx-auto px-6 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center min-h-[70vh]">
            <div className="text-left">
              <h1 className="text-5xl md:text-6xl font-bold mb-8 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent leading-tight">
                Servicios IT de Excelencia
              </h1>
              <p className="text-xl md:text-2xl mb-12 text-gray-300 leading-relaxed">
                Potencie su negocio con servicios IT en línea de excelencia en Centroamérica. 
                Expertos en desarrollo, soporte y ciberseguridad. Confíe en nosotros.
              </p>
            </div>
            {/* Right side - space for building background visibility */}
            <div className="hidden md:block relative">
              <div className="absolute inset-0 bg-gradient-to-l from-transparent to-gray-900/20 z-10"></div>
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="bg-black/40 backdrop-blur-md py-16">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-4xl font-bold text-center mb-12 text-green-400">Contáctanos</h2>
              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div className="bg-gray-800/50 backdrop-blur-sm p-8 rounded-2xl border border-green-500/20">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2 text-green-400">Nombre</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 bg-gray-900/50 border border-green-500/30 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-white"
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2 text-green-400">País</label>
                        <select
                          name="country"
                          value={formData.country}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-gray-900/50 border border-green-500/30 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-white"
                        >
                          {countries.map(country => (
                            <option key={country.code} value={country.code}>
                              {country.code} {country.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2 text-green-400">Teléfono</label>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-gray-900/50 border border-green-500/30 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-white"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2 text-green-400">Email</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 bg-gray-900/50 border border-green-500/30 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-white"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2 text-green-400">Idioma</label>
                      <select
                        name="language"
                        value={formData.language}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 bg-gray-900/50 border border-green-500/30 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-white"
                      >
                        <option value="es">Español</option>
                        <option value="en">English</option>
                        <option value="pt">Português</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-green-600 hover:bg-green-700 px-6 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-xl shadow-green-500/25"
                    >
                      Enviar
                    </button>
                  </form>
                </div>

                <div className="text-center md:text-left">
                  <img 
                    src="https://images.unsplash.com/photo-1606836559739-7b1d9fbf8a6e" 
                    alt="Consulta profesional" 
                    className="w-full h-80 object-cover rounded-2xl mb-6 shadow-2xl"
                  />
                  <h3 className="text-2xl font-bold mb-4 text-green-400">¿Listo para transformar tu negocio?</h3>
                  <p className="text-gray-300 leading-relaxed">
                    Nuestros expertos están listos para ayudarte a implementar las mejores soluciones tecnológicas 
                    para tu empresa en Centroamérica.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* What's Next Process Section */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-green-400">
              ¿Qué Sigue? Nuestro Proceso Clave
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  number: "1",
                  title: "Consulta Inicial",
                  description: "Discutiremos las necesidades y objetivos de su negocio durante una llamada de 30 minutos.",
                  image: "https://images.unsplash.com/photo-1513470270416-d3ff6f16b22f"
                },
                {
                  number: "2", 
                  title: "Propuesta Personalizada",
                  description: "Prepararemos una solución a medida basada en sus requisitos específicos.",
                  image: "https://images.unsplash.com/photo-1584466990297-7e8ab67a5eb0"
                },
                {
                  number: "3",
                  title: "Implementación", 
                  description: "Nuestro equipo trabajará con usted para implementar la solución sin problemas.",
                  image: "https://images.unsplash.com/photo-1496115965489-21be7e6e59a0"
                }
              ].map((step, index) => (
                <div key={index} className="bg-gray-800/50 backdrop-blur-sm p-8 rounded-2xl border border-green-500/20 text-center transform hover:scale-105 transition-all duration-300">
                  <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                    {step.number}
                  </div>
                  <img 
                    src={step.image}
                    alt={step.title}
                    className="w-full h-48 object-cover rounded-lg mb-6 shadow-lg"
                  />
                  <h3 className="text-xl font-bold mb-4 text-green-400">{step.title}</h3>
                  <p className="text-gray-300 leading-relaxed">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Payment Solutions Section */}
        <section className="bg-black/40 backdrop-blur-md py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold mb-8 text-green-400">
                  Soluciones de Pago Seguras y Modernas
                </h2>
                <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                  Nuestros sistemas de pago integrados garantizan transacciones fluidas y seguras para su negocio y clientes. 
                  Soportamos múltiples métodos de pago y monedas.
                </p>
                <ul className="space-y-4">
                  {[
                    "Procesamiento de pagos seguro",
                    "Soporte para múltiples monedas", 
                    "Facturación automatizada"
                  ].map((feature, index) => (
                    <li key={index} className="flex items-center space-x-3">
                      <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="text-center">
                <img 
                  src="https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1"
                  alt="Soluciones de Pago"
                  className="w-full h-80 object-cover rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Strategic Partner Section */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="text-center md:order-2">
                <img 
                  src="https://images.pexels.com/photos/8358039/pexels-photo-8358039.jpeg"
                  alt="Alianza Estratégica"
                  className="w-full h-80 object-cover rounded-2xl shadow-2xl"
                />
              </div>
              <div className="md:order-1">
                <h2 className="text-4xl font-bold mb-8 text-green-400">
                  Su Socio Estratégico en Tecnología Empresarial
                </h2>
                <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                  Servimos como su socio tecnológico a largo plazo, entregando soluciones empresariales que impulsan 
                  la innovación y ventaja competitiva en su industria.
                </p>
                <ul className="space-y-4 mb-8">
                  {[
                    "Soluciones personalizadas para sus necesidades específicas",
                    "Gerente de cuenta dedicado para soporte personalizado",
                    "Revisiones regulares de rendimiento y optimización"
                  ].map((feature, index) => (
                    <li key={index} className="flex items-center space-x-3">
                      <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className="bg-green-600 hover:bg-green-700 px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-xl shadow-green-500/25">
                  Conoce Nuestros Servicios
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-black/60 backdrop-blur-md border-t border-green-500/20 py-12">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-4 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4 text-green-400">Servicios IT</h3>
                <p className="text-gray-400">
                  Expertos en tecnología para Centroamérica
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-white">Servicios</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>Desarrollo Web</li>
                  <li>Ciberseguridad</li>
                  <li>Soporte IT</li>
                  <li>Consultoría</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-white">Empresa</h4>
                <ul className="space-y-2 text-gray-400">
                  <li>Acerca de</li>
                  <li>Casos de Estudio</li>
                  <li>Contacto</li>
                  <li>Blog</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-white">Contacto</h4>
                <div className="text-gray-400 space-y-2">
                  <p>roberto.luna.e@proton.me</p>
                  <p>Guatemala, Guatemala Ciudad Capital.</p>
                </div>
              </div>
            </div>
            <div className="border-t border-green-500/20 mt-8 pt-8 text-center text-gray-400">
              <p>&copy; 2025 Servicios IT. Todos los derechos reservados.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default App;